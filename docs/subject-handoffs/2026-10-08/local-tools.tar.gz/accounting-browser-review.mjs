import { chromium } from '/Users/alexlinehan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { mkdirSync, writeFileSync } from 'node:fs';
const root='/Users/alexlinehan/Documents/Nextstepuni-Accounting-Completion-20261007/tmp/accounting/browser-'+[process.argv[2],process.argv[3],process.argv[4]??'higher'].join('-');
mkdirSync(root,{recursive:true});
const browser=await chromium.launch({headless:true,channel:'chrome'});
const results=[];
for (const [name,width,height] of [['desktop',1440,1000],['phone',390,844],['atlas-phone',390,844]]) {
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE ERROR',e.message)});page.on('requestfailed',r=>console.log('FAILED',r.url(),r.failure()));page.on('response',r=>{if(r.status()>=400)console.log('HTTP',r.status(),r.url())});
 await page.goto('http://127.0.0.1:5279/tmp/accounting/review.html?year='+(process.argv[2]??'2025')+'&task='+(process.argv[3]??'7')+'&level='+(process.argv[4]??'higher')+(name.startsWith('atlas')?'&view=atlas':''));
 await page.getByRole('button',{name:/Open accounting data/}).waitFor();
 await page.screenshot({path:`${root}/${name}-question.png`});
 await page.getByRole('button',{name:/Open accounting data/}).click();
 await page.getByRole('dialog').locator('canvas').first().waitFor({timeout:20000}).catch(async e=>{await page.screenshot({path:`${root}/${name}-data-failure.png`});console.log(await page.getByRole('dialog').innerText());await browser.close();throw e});
 await page.screenshot({path:`${root}/${name}-data.png`});
 await page.getByRole('button',{name:'Close accounting data'}).click();
 await page.getByRole('button',{name:name.startsWith('atlas')?'Show the marking scheme':/Reveal/}).click();
 await page.getByRole('button',{name:/Open worked solution/}).click();
 const first=page.getByRole('dialog').locator('canvas').first();
 await first.waitFor({timeout:45000});
 await page.screenshot({path:`${root}/${name}-solution.png`});
 if(process.argv[3]==='8(f)'){
  await page.locator('.mb-source-reader-page-pan').first().evaluate(el=>{el.scrollTop=el.scrollHeight;});
  await page.screenshot({path:`${root}/${name}-graph.png`});
  await page.locator('.mb-source-reader-page-pan').first().evaluate(el=>{el.scrollTop=0;});
 }
 const before=await first.boundingBox();
 if(['2023:4:higher','2022:4:ordinary','2010:2:ordinary'].includes([process.argv[2],process.argv[3],process.argv[4]??'higher'].join(':')) && before.width<before.height)throw new Error('Sideways table did not become landscape');
 for(let i=0;i<8;i++)await page.getByRole('button',{name:'Zoom in',exact:true}).click();
 await page.waitForTimeout(500);
 const after=await first.boundingBox();
 const pan=page.locator('.mb-source-reader-page-pan').first();
 const panRange=await pan.evaluate(el=>({width:el.clientWidth,total:el.scrollWidth}));
 if(after.width < before.width*2.7)throw new Error('Zoom did not enlarge the table');
 await pan.evaluate(el=>{el.scrollLeft=el.scrollWidth;});
 const scrollLeft=await pan.evaluate(el=>el.scrollLeft);
 if(scrollLeft<=0)throw new Error('Table cannot pan');
 await page.screenshot({path:`${root}/${name}-solution-zoom.png`});
 if(process.argv[3]==='8(f)'){
  await pan.evaluate(el=>{el.scrollLeft=(el.scrollWidth-el.clientWidth)/2;el.scrollTop=el.scrollHeight;});
  await page.screenshot({path:`${root}/${name}-graph-zoom.png`});
 }
 results.push({name,errors,canvas:await first.evaluate(c=>({width:c.width,height:c.height})),before,after,panRange,scrollLeft});
 await page.getByRole('button',{name:'Next source page'}).click();
 await page.keyboard.press('Escape');
 await page.waitForFunction(() => document.activeElement?.textContent?.includes('Open worked solution'), {timeout:3000});
 await page.close();
}
writeFileSync(`${root}/results.json`,JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
await browser.close();
