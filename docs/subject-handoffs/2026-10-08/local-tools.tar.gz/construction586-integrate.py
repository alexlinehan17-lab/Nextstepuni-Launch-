from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
R=Path('/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926');D=R/'docs/markbank-audit/2026-09-28';A=D/'drafts/construction-2015-higher-q7-q10-integration';T=Path('/tmp/construction586')
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
report=read(D/'construction-q3-q6-validation.json');assert report['newTasks']==56 and all(c['exitCode']==0 for c in report['validation'])
reviewPath=R/'scripts/markbank/authored/construction-studies-2015-higher-reviewed.json';d=read(reviewPath);assert len(d['tasks'])==63 and d['questionsReviewed']==list(map(str,range(1,7)))
auth=R/'scripts/markbank/authored/construction-studies.json';prior=read(auth);assert len(prior)==568
packages=[]
for q,n,count in [(7,581,5),(8,583,6),(9,584,13),(10,585,15)]:
 archive=D/f'drafts/construction-2015-higher-q{q}-draft';draft=read(archive/f'q{q}-draft.json');assert len(draft['tasks'])==count and draft['sourceHashes']==d['sourceHashes']and all(f['visuallyInspected']for f in draft['questionFigures'])
 pf=read(archive/'preflight.json');sv=read(archive/'source-validation.json');assert pf['sourceClaims']and pf['canonicalTopics']and pf['taskGroups']
 assert (len(sv['rejectedMutations'])>=12 and sv['tasks']==count)if q==7 else(sv['passed']and sv['negativeMutationsRejected']>=12 and sv['report']['tasks']==count)
 for f in draft['questionFigures']:assert hashlib.sha256((archive/(f['key']+'.png')).read_bytes()).hexdigest()==f['sha256']
 packages.append((q,n,archive,draft))
new=[t for _,_,_,p in packages for t in p['tasks']];ids=[t['card']['id']for t in new];assert len(ids)==len(set(ids))==39 and not set(ids)&{c['id']for c in prior}
mp=R/'components/MarkBank/figures-construction-studies.json';manifest=read(mp);assert len(manifest)==23 and len(d['questionFigures'])==23
# Preflight every path and duplicate content before making any runtime mutation.
seen={e['md5']:k for k,e in manifest.items()}
for q,n,archive,p in packages:
 for f in p['questionFigures']:
  src=archive/(f['key']+'.png');md5=hashlib.md5(src.read_bytes()).hexdigest();assert f['key']not in manifest and md5 not in seen;seen[md5]=f['key'];assert not(R/'public/exam-figures/construction-studies/markbank'/src.name).exists()
 assert not(R/f'scripts/markbank/authoring/construction_2015_higher_q{q}.py').exists()
A.mkdir(exist_ok=True);T.mkdir(exist_ok=True);save(A/'prior-authored-cards.json',prior);save(A/'prior-reviewed-q1-q6.json',d)
for q,n,archive,p in packages:
 for f in p['questionFigures']:
  key=f['key'];src=archive/(key+'.png');dst=R/'public/exam-figures/construction-studies/markbank'/src.name;shutil.copyfile(src,dst)
  label=key.split(f'q{q}-',1)[1].replace('-',' ');manifest[key]=dict(src='/'+str(dst.relative_to(R/'public')),md5=hashlib.md5(dst.read_bytes()).hexdigest(),alt=f'Original SEC 2015 Higher Construction Studies Question {q}: '+(f'source question and illustration, {label}.'if not f['solution']else'marking-scheme model illustrations. Apply only the selected printed tasks; examples do not create extra choices.'),attribution='SEC Leaving Certificate Construction Studies 2015 Higher Level — © State Examinations Commission.',solution=f['solution'])
 for field in ['tasks','bindings','questionFigures','addedIds']:d[field]+=p[field]
 d.setdefault('questionRouteLedgers',{})[str(q)]=p['routeLedger'];d.setdefault('questionDraftReviews',{})[str(q)]=str((archive/f'q{q}-draft.json').relative_to(R))
 source=(archive/f'construction{n}-review.py').read_text().replace("R=Path('/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926')","R=Path(__file__).resolve().parents[3]").replace(f"T=Path('/tmp/construction{n}')",f"T=R/'{archive.relative_to(R)}'")
 (R/f'scripts/markbank/authoring/construction_2015_higher_q{q}.py').write_text(source)
now=datetime.now(timezone.utc).isoformat();d.update(status='Q1–Q10 drafts source-reviewed and integrated locally; Q7–Q10 runtime validation and full-paper reconciliation pending. No paper-completion claim.',reviewedAt=now,questionsReviewed=list(map(str,range(1,11))),unreviewedQuestions=[],paperComplete=False,fullPaperReconciliation='pending');assert len(d['tasks'])==102 and len(d['questionFigures'])==35
save(reviewPath,d);save(mp,manifest);save(auth,prior+[t['card']for t in new]);assert read(auth)[:568]==prior
bp=R/'scripts/markbank/atlas-reviews/construction-studies-2015-higher.json';bridge=read(bp);assert len(bridge['cards'])==63;bridge.update(reviewedAt=now,expectedRuntimeCards=102,reason='Q1–Q10 source boundaries reviewed. Exact printed source and all constituent topics retained; primary and alternative Q10 share the original Q10 anchor. Runtime and whole-paper reconciliation pending.',cards=d['bindings'],questions=[dict(n=q,fileid='LC029ALP000EV.pdf',topicIds=sorted({t for b in d['bindings']if b['questionNumber']==q for t in b['atlasTopicIds']}))for q in d['questionsReviewed']]);save(bp,bridge)
p=R/'test/fixtures/construction2015Reviewed.ts';s=p.read_text();old='export const CONSTRUCTION_2015_HIGHER_REVIEWED_IDS = [...CONSTRUCTION_2015_HIGHER_Q1_Q2_ADDED_IDS, ...CONSTRUCTION_2015_HIGHER_Q3_Q6_ADDED_IDS];';assert s.count(old)==1;s=s.replace(old,'// Q7–Q10 include every printed choice and the separate Q10 alternative.\nexport const CONSTRUCTION_2015_HIGHER_Q7_Q10_ADDED_IDS = '+json.dumps(ids,indent=2).replace('"',"'")+';\n\nexport const CONSTRUCTION_2015_HIGHER_REVIEWED_IDS = [...CONSTRUCTION_2015_HIGHER_Q1_Q2_ADDED_IDS, ...CONSTRUCTION_2015_HIGHER_Q3_Q6_ADDED_IDS, ...CONSTRUCTION_2015_HIGHER_Q7_Q10_ADDED_IDS];');p.write_text(s)
p=R/'test/markBankConstruction2015HigherReviewed.test.ts';s=p.read_text().replace('source-reviewed Q1–Q6','source-reviewed Q1–Q10').replace('{figureKey?: string}','{figureKey?: string; questionFigureKey: string}')
needle="  it('preserves all previous authored cards unchanged'";assert s.count(needle)==1;s=s.replace(needle,"  it('reconciles Q7–Q10 routes, the alternative essay and source figures', () => {\n    const result = JSON.parse(execFileSync('python3', ['scripts/markbank/authoring/construction_2015_higher_q7_q10.py'], { encoding: 'utf8' }));\n    expect(result).toEqual({tasks: 39, sourceFigures: 12, wholeQuestionRoutes: 10, paperComplete: false});\n  });\n"+needle)
s=s.replace('`q${binding.questionNumber}-original.png`','`${source.questionFigureKey}.png`').replace("['1', '2', '3', '4', '5', '6']","['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']");p.write_text(s)
missing=[x for _,_,a,_ in packages for x in read(a/'preflight.json')['missingAtlasAssociations']];assert len(missing)==14
save(A/'integration.json',dict(checkpoint=586,reviewedAt=now,addedTasks=39,totalReviewedTasks=102,priorAuthoredCardsPreserved=568,newAuthoredCount=607,newFigures=12,wholeRoutesAdded=10,sourcePackages=[str(a.relative_to(R))for _,_,a,_ in packages],missingAtlasAssociations=missing,status='Authored/bridge changes applied; generator/compile/runtime checks and final whole-paper reconciliation pending.'))
shutil.copyfile('/tmp/construction586-integrate.py',A/'construction586-integrate.py')
p=D/'construction-active-resume-2026-10-07.json';r=read(p);r.update(checkpoint=586,updatedAt=now,activeBatch='2015 Higher Q7–Q10:39 new tasks,102 reviewed tasks total',validationPending=True,liveProcesses=[],q10Draft='drafts/construction-2015-higher-q10-draft/q10-draft.json',next='Install Q7–Q10 source wrapper, regenerate Atlas/library/subject deck, run regression/Atlas/types/lint. Then independent source-to-card full2015Higherpaper reconciliation before any completion claim.');save(p,r)
print('Applied39tasks/12figures/14Atlas associations;607authoredcards. Runtime validation pending.')
