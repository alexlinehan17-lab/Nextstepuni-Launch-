from pathlib import Path
import subprocess,os,json,hashlib,sys,re
R=Path('/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926');T=Path('/tmp/construction586');T.mkdir(exist_ok=True)
plan=[('source-q1-q2',['python3','-m','unittest','discover','-s','scripts/markbank/authoring','-p','test_construction_2015_higher_q1_q2.py']),('source-q3-q6',['python3','scripts/markbank/authoring/construction_2015_higher_q3_q6.py']),('source-q7-q10',['python3','scripts/markbank/authoring/construction_2015_higher_q7_q10.py']),('atlas-generation',['node','scripts/paper-trail/build-construction-studies-exam-topic-crosswalk.mjs']),('library-generation',['node','scripts/markbank/build-library-topic-index.mjs']),('deck-build',['node','scripts/markbank/build-deck.mjs','scripts/markbank/authored/construction-studies.json']),('regression',['npx','vitest','run','test/markBankConstruction2015HigherReviewed.test.ts','test/constructionStudiesExamTopics.test.ts','test/markBankCardPreservation.test.ts','test/curriculumRegistry.test.ts','test/markBankDeck.test.ts','--maxWorkers=1','--testTimeout=600000']),('atlas',['npm','run','check:markbank-atlas','--','--maxWorkers=1','--testTimeout=600000']),('types-test',['node','--max-old-space-size=12288','node_modules/typescript/lib/tsc.js','--noEmit','-p','tsconfig.test.json']),('lint',['npx','eslint','test/markBankConstruction2015HigherReviewed.test.ts','test/constructionStudiesExamTopics.test.ts','test/markBankCardPreservation.test.ts','test/fixtures/construction2015Reviewed.ts'])]
start=next(i for i,(n,_)in enumerate(plan)if n==sys.argv[1])if len(sys.argv)>1 else 0
checks=json.loads((T/'checks.json').read_text())[:start]if start else [];assert all(c['exitCode']==0 for c in checks)
for name,cmd in plan[start:]:
 log=T/(name+'.log');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size='+('12288'if name=='types-test'else '8192'))
 with log.open('w')as out:code=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 if name=='deck-build'and code==0 and not re.search(r'Construction Studies: built 607 cards, dropped 0',log.read_text()):
  code=65
  with log.open('a')as out:out.write('\nBATCH GUARD FAILED: expected607cards andzero drops.\n')
 checks.append(dict(name=name,command=cmd,exitCode=code,log=str(log),logSha256=hashlib.sha256(log.read_bytes()).hexdigest()));(T/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,code,flush=True)
 if code:sys.exit(code)
