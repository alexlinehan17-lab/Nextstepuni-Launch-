from pathlib import Path
import json,hashlib,copy,re,fitz
from PIL import Image,ImageChops
R=Path('/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926');T=Path('/tmp/construction589');P='examiner-reports/construction-studies/papers/2015-ol-paper.pdf';S='examiner-reports/construction-studies/2015-ol-marking-scheme.pdf';prefix='cons-2015-ol-q1-';fp='construction-studies-2015-OL-q1-'
def validate(d,images=True):
 hashes={P:'6a5e6c2c39fcfc5d7d3d4eebae139ed927eaaaa16fb429d0eab333c3f0d7e99f',S:'ca21a4dccfd47aea12de99758ce82058a9b33138a0ab9742dba1197b47364e07'};assert d['sourceHashes']==hashes
 for f,h in hashes.items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h
 cards={t['card']['id'].removeprefix(prefix):t['card']for t in d['tasks']};assert set(cards)=={'a','b','complete'}and len(d['tasks'])==len(d['bindings'])==3 and d['addedIds']==[t['card']['id']for t in d['tasks']]
 nodes={'a':['cons-3-8','cons-3-9','cons-3-3','cons-6-2'],'b':['cons-3-8','cons-3-3']};nodes['complete']=nodes['a'];topics={'a':['roofs','foundations-floors-walls','heat-loss-insulation'],'b':['roofs','foundations-floors-walls']};topics['complete']=topics['a'];bs={b['cardId']:b for b in d['bindings']}
 for k,c in cards.items():
  expected={'a':40,'b':2,'complete':50}[k];assert c['totalMarks']==expected==sum(r['marks']for r in c['rows'])+c.get('questionBonus',{}).get('marks',0)and c['tariffModel']=={'kind':'fixed'}
  assert(c['subjectId'],c['year'],c['level'])==('construction-studies',2015,'ordinary')and c['questionFigureKey']==fp+'original'and c['figureKey']==fp+'roof-section'and c['sourceMaterial']['pages']==[1,2]
  for s in ['TILED','30°','2.0 m','400 mm','200 mm full-fill','200 mm × 40 mm','UNDER the ceiling joists','1:5','400 mm below','THREE courses of tiles','FOUR typical dimensions','front door is not required']:assert s in c['stem']
  assert c['questionRef'].startswith('2015 OL Q1')
  if k!='complete':assert 'questionBonus'not in c and 'taskGroups'not in c
  b=bs[c['id']];assert b['questionNumber']=='1'and b['canonicalTopicIds']==nodes[k]and b['atlasTopicIds']==['construction-studies-ordinary-'+t for t in topics[k]]and b['markBankTopicId']==c['topicId']==nodes[k][0]
  t=next(t for t in d['tasks']if t['card']['id']==c['id']);assert t['questionNumber']=='1'and t['requiredQuestionFigures']==[fp+'original']and t['requiredSolutionFigures']==[fp+'roof-section']
  assert {(x['file'],x['page'])for x in t['sourceChecks']}=={(P,1),(P,2),(S,2),(S,4),(S,17)}
  for x in t['sourceChecks']:
   with fitz.open(R/x['file'])as pdf:assert hashlib.sha256(' '.join(pdf[x['page']-1].get_text().split()).encode()).hexdigest()==x['textSha256']
 assert[(r['marks'],r['permittedMarks'])for r in cards['a']['rows']]==[(36,list(range(0,37,4))),(4,[0,4])]
 assert[(r['marks'],r['permittedMarks'])for r in cards['b']['rows']]==[(2,[0,2])]
 assert 'best NINE'in cards['a']['rows'][0]['contextNote']and 'do not import'in cards['a']['rows'][0]['contextNote']and 'BOTH wall and wallplate'in cards['b']['rows'][0]['contextNote']
 bonus=cards['complete']['questionBonus'];assert bonus['id']=='drawing-quality'and bonus['kind']=='criterion'and bonus['marks']==8 and bonus['permittedMarks']==[0,4,6,8]and bonus['verbatim']=='Draughting, accuracy and scale'and 'Apply once'in bonus['contextNote']
 rows=[]
 assert[g['sourceCardId']for g in cards['complete']['taskGroups']]==[prefix+'a',prefix+'b']
 for k,g in zip(['a','b'],cards['complete']['taskGroups']):
  rs=copy.deepcopy(cards[k]['rows'])
  for r in rs:r['id']=k+'-'+r['id']
  assert g['marks']==cards[k]['totalMarks']and g['rowIds']==[r['id']for r in rs];rows+=rs
 assert cards['complete']['rows']==rows and cards['complete']['questionText']==cards['a']['questionText']+'\n\n'+cards['b']['questionText']
 assert d['routeLedger']['wholeRoutes']==[dict(id=prefix+'complete',parts=['a','b'],componentMarks=[40,2],sharedQualityMarks=8,marks=50)]and len(d['routeLedger']['nonChoices'])==2
 specs={'original':(P,2,[38,34,580,221],False),'roof-section':(S,4,[54,54,568,752],True)};assert len(d['questionFigures'])==2
 for f in d['questionFigures']:
  assert(f['source'],f['page'],f['rect'],f['solution'])==specs[f['key'].removeprefix(fp)]and f['visuallyInspected'];p=T/(f['key']+'.png');assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
  if images:
   with fitz.open(R/f['source'])as pdf:px=pdf[f['page']-1].get_pixmap(matrix=fitz.Matrix(2,2),clip=fitz.Rect(f['rect']),alpha=False)
   a=Image.frombytes('RGB',(px.width,px.height),px.samples);b=Image.open(p).convert('RGB');assert a.size==b.size and ImageChops.difference(a,b).getbbox()is None
 ledger=d['selectionLedger'];observed=[]
 with fitz.open(R/P)as pdf:
  for i,p in enumerate(pdf):observed.extend((i+1,m.start(),m.group())for m in re.finditer(ledger['pattern'],' '.join(p.get_text().split()),re.I))
 assert observed==[(r['page'],r['start'],r['match'])for r in ledger['rows']]and len(observed)==3 and ledger['unclassified']==0
 return dict(tasks=3,wholeQuestionRoutes=1,figures=2,sharedQualityMarks=8,sourcePagesChecked=True)
if __name__=='__main__':print(json.dumps(validate(json.loads((T/'q1-draft.json').read_text()))))
