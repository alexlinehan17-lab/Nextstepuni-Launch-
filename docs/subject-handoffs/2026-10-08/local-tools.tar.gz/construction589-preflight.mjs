import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createServer} from '/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926/node_modules/vite/dist/node/index.js';
import {comparableScheme,claimMatches} from '/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926/scripts/markbank/schemeText.mjs';
import {taskGroupsFault} from '/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926/scripts/markbank/taskGroups.mjs';
import {isContentFreeRow} from '/Users/alexlinehan/Documents/Nextstepuni-Filled-Dark-Artwork-20260926/scripts/markbank/contentFree.mjs';
const draft=JSON.parse(fs.readFileSync('/tmp/construction589/q1-draft.json'));
const scheme=comparableScheme(fs.readFileSync('/tmp/construction588/scheme.txt','utf8'));
for (const {card} of draft.tasks){assert.equal(taskGroupsFault(card),null);for(const r of [...card.rows, ...(card.questionBonus?[card.questionBonus]:[])]){assert.ok(claimMatches(scheme,r.verbatim),r.verbatim);assert.equal(isContentFreeRow(r.verbatim),false,r.verbatim);}}
const server=await createServer({configFile:false,optimizeDeps:{noDiscovery:true,include:[]},server:{middlewareMode:true,hmr:false,ws:false},appType:'custom'});
try{
 const {resolveCurriculumSpecification,findCanonicalTopic}=await server.ssrLoadModule('/curriculumRegistry.ts');
 const {examTopicIdsForQuestion,curriculumNodeIdsForExamQuestion}=await server.ssrLoadModule('/data/examTopics/registry.ts');
 const spec=resolveCurriculumSpecification('construction-studies',2015);assert.equal(spec.id,'construction-studies:outgoing');
 const crosswalk=JSON.parse(fs.readFileSync('data/examTopics/construction-studies-curriculum-crosswalk.json'));
 const missing=[];
 for(const b of draft.bindings){
  for(const id of b.canonicalTopicIds)assert.equal(findCanonicalTopic(spec,id)?.id,id);
  for(const id of b.atlasTopicIds)assert.ok(crosswalk[id],id);
  for(const id of b.canonicalTopicIds)assert.ok(b.atlasTopicIds.flatMap(t=>crosswalk[t]).includes(id),id);
  const current=examTopicIdsForQuestion('construction-studies','ordinary',2015,'main',b.questionNumber,'single','ev','LC029GLP000EV.pdf');
  missing.push(...b.atlasTopicIds.filter(id=>!current.includes(id)).map(id=>({question:b.questionNumber,topic:id})));
 }
 fs.writeFileSync('/tmp/construction589/preflight.json',JSON.stringify({cards:draft.tasks.length,sourceClaims:true,taskGroups:true,canonicalTopics:true,missingAtlasAssociations:[...new Map(missing.map(x=>[JSON.stringify(x),x])).values()]},null,2)+'\n');
 console.log(fs.readFileSync('/tmp/construction589/preflight.json','utf8'));
}finally{await server.close();}
