from pathlib import Path
import fitz,sys
from PIL import Image,ImageDraw
r=Path('/Users/alexlinehan/Documents/Nextstepuni-Accounting-Completion-20261007');year=int(sys.argv[1]);lang=sys.argv[2] if len(sys.argv)>2 else 'EV'
for level,c in [('higher','A'),('ordinary','G')]:
 for kind,folder in [('paper','exampapers'),('scheme','markingschemes')]:
  src=r/f'paper-trail-corpus/{folder}/{year}/LC032{c}LP000{lang}.pdf'
  if not src.exists(): continue
  d=fitz.open(src);dest=r/'tmp/accounting/render';dest.mkdir(exist_ok=True)
  (r/f'tmp/accounting/text/{year}-{level}-{lang.lower()}-{kind}.txt').write_text('\n'.join(f'\n=== PDF PAGE {p.number+1} ===\n'+p.get_text() for p in d))
  for start in range(0,len(d),4):
   sheet=Image.new('RGB',(1500,2180),'#ddd');draw=ImageDraw.Draw(sheet)
   for i in range(start,min(start+4,len(d))):
    p=d[i];pix=p.get_pixmap(matrix=fitz.Matrix(1.3,1.3));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.thumbnail((740,1045));x=(i-start)%2*750;y=(i-start)//2*1090;sheet.paste(im,(x,y+30));draw.text((x+10,y+8),f'{year} {level} {kind} PDF {i+1}',fill='black')
   sheet.save(dest/f'{year}-{level}-{lang.lower()}-{kind}-{start+1}.jpg',quality=92)
  print(level,kind,len(d))
