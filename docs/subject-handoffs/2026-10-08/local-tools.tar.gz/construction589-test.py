import json,copy,runpy
from pathlib import Path
v=runpy.run_path('/tmp/construction589-review.py')['validate'];d=json.loads(Path('/tmp/construction589/q1-draft.json').read_text());report=v(d)
changes=[lambda x:x['tasks'][0]['card'].update(totalMarks=48),lambda x:x['tasks'][1]['card'].update(totalMarks=10),lambda x:x['tasks'][-1]['card'].pop('questionBonus'),lambda x:x['tasks'][-1]['card']['questionBonus'].update(marks=16),lambda x:x['tasks'][-1]['card']['questionBonus'].update(permittedMarks=[0,2,4,6,8]),lambda x:x['tasks'][0]['card']['rows'][0].update(permittedMarks=list(range(37))),lambda x:x['tasks'][0]['card'].update(stem='Scale1:10 roof45degrees'),lambda x:x['tasks'][1]['card']['rows'][0].update(contextNote='Strap attached only to wall'),lambda x:x['bindings'][-1]['atlasTopicIds'].pop(),lambda x:x['tasks'][-1]['card']['taskGroups'].pop(),lambda x:x['questionFigures'][1].update(rect=[54,54,300,752]),lambda x:x['selectionLedger']['rows'].pop()]
for i,change in enumerate(changes):
 x=copy.deepcopy(d);change(x)
 try:v(x,False)
 except AssertionError:continue
 raise AssertionError('Mutation escaped '+str(i))
Path('/tmp/construction589/source-validation.json').write_text(json.dumps(dict(passed=True,negativeMutationsRejected=12,report=report),indent=2)+'\n');print(report,'12mutationsrejected')
