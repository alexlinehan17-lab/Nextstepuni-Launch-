import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import '../../index.css';
import SessionScreen from '../../components/MarkBank/SessionScreen';
import VaultQuestionCard from '../../components/PaperTrail/VaultQuestionCard';
import {PHYSICAL_EDUCATION_TASKS} from '../../components/PaperTrail/physicalEducationTasks';
import {REVIEWED_CARDS} from '../../components/MarkBank/cards/physical-education/factory';
function App(){
 const [id,setId]=useState('pe-2020-hl-q11bi'),[mode,setMode]=useState('atlas'),[dark,setDark]=useState(false),[saved,setSaved]=useState(false);
 const card=REVIEWED_CARDS.find(c=>c.id===id)!; const task=PHYSICAL_EDUCATION_TASKS.find(t=>t.cardId===id)!;
 return <div style={{minHeight:'100vh',background:dark?'#191817':'#f5f1eb',padding:'24px 12px'}}>
 <div style={{maxWidth:1000,margin:'0 auto 24px',display:'flex',flexWrap:'wrap',gap:16,color:dark?'white':'black',position:'relative',zIndex:1}}>
 <label>View <select aria-label="View" style={{color:"black"}} value={mode} onChange={e=>setMode(e.target.value)}><option value="atlas">Topic Atlas</option><option value="bank">Mark Bank</option></select></label>
 <label style={{display:"flex",gap:6,minWidth:0,maxWidth:"100%"}}>Task <select aria-label="Task" style={{color:"black",maxWidth:"100%",minWidth:0}} value={id} onChange={e=>setId(e.target.value)}>{REVIEWED_CARDS.map(c=><option key={c.id} value={c.id}>{c.id}</option>)}</select></label>
 <button style={{border:'1px solid',padding:'4px 12px'}} onClick={()=>{document.documentElement.classList.toggle('dark',!dark);setDark(!dark)}}>Toggle theme</button>
 </div>
 <div style={{maxWidth:680,margin:'auto'}}>{mode==='atlas'?<VaultQuestionCard key={id} sibling={task} saved={saved} onToggleReview={()=>setSaved(!saved)} onOpenInPaper={()=>window.alert('Full paper Q'+task.parentQuestion)} />:<SessionScreen key={id} cards={[card]} subjectLabel="Physical Education" onGrade={()=>{}} onFinish={()=>{}} onExit={()=>setMode('atlas')} />}</div>
 </div>
}
createRoot(document.getElementById('root')!).render(<App/>);
