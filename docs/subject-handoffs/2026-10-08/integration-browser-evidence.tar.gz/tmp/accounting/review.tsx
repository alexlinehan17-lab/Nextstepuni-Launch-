import React from 'react';
import { createRoot } from 'react-dom/client';
import '../../index.css';
import SessionScreen from '../../components/MarkBank/SessionScreen';
import VaultQuestionCard from '../../components/PaperTrail/VaultQuestionCard';
import { questionsForTopics } from '../../components/PaperTrail/topics';
import { CARDS as HIGHER } from '../../components/MarkBank/cards/accounting/higher';
import { CARDS as ORDINARY } from '../../components/MarkBank/cards/accounting/ordinary';
const params = new URLSearchParams(location.search);
const key = params.get('task') ?? '7';
const year = Number(params.get('year') ?? 2025);
const level = params.get('level') ?? 'higher';
const card = [...HIGHER, ...ORDINARY].find(c => c.year === year && c.level === level && c.questionRef.endsWith(`Q${key}`))!;
const sibling = questionsForTopics('accounting',null).find(q => q.year === year && q.level === level && q.n === key)!;
createRoot(document.getElementById('root')!).render(params.get('view') === 'atlas'
  ? <main style={{maxWidth:1000,margin:'30px auto',padding:16}}><VaultQuestionCard sibling={sibling} saved={false} onToggleReview={() => {}} onOpenInPaper={() => {}} /></main>
  : <SessionScreen cards={[card]} subjectLabel="Accounting" onGrade={() => {}} onFinish={() => {}} onExit={() => {}} />);
