import { chromium } from '/Users/alexlinehan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
if (process.argv[2] === 'atlas') { await import('./atlas-browser.mjs'); process.exit(0); }
const target = process.argv[2] || 'am-2026-ol-3-i-4kg';
const label = process.argv[3] || 'Published step 1';
const selected = Number(process.argv[4] || 5);
const browser = await chromium.launch({headless: true, channel:'chrome'});
try {
for (const [name,width,height] of [['desktop',1440,1000],['phone',390,844]]) {
 const page=await browser.newPage({viewport:{width,height}});
 const errors=[]; page.on('pageerror',e=>{errors.push(e.message);console.log('ERROR',e.message)}); page.on('requestfailed',r=>console.log('FAILED',r.url(),r.failure())); page.on('response',r=>{if(r.status()>=400)console.log('HTTP',r.status(),r.url())});
 await page.goto(`http://127.0.0.1:5488/tmp/applied-mathematics-review/preview.html?card=${target}`);
 const question=page.getByRole('button',{name:/Read.*question and context/});
 await question.waitFor(); await page.waitForTimeout(500);
 await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-question.png`});
 await question.click();
 await page.getByRole('dialog').locator('canvas').first().waitFor({timeout:25000}).catch(async e=>{console.log(await page.getByRole('dialog').innerText());await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-failure.png`});throw e;});
 await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-paper.png`});
 if (await page.getByRole('button',{name:'Next source page'}).isEnabled()) {
  await page.getByRole('button',{name:'Next source page'}).click();
  await page.waitForTimeout(700);
  await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-paper-next.png`});
  console.log(JSON.stringify({name,paperSecondPage:await page.getByRole('dialog').innerText()}));
 }
 await page.getByRole('button',{name:'Close question pages'}).click();
 await page.getByRole('button',{name:'Reveal the marking scheme'}).click();
 await page.getByRole('button',{name:/Read.*worked solution/}).click();
 await page.getByRole('dialog').locator('canvas').first().waitFor({timeout:25000}).catch(async e=>{console.log(await page.getByRole('dialog').innerText());await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-failure.png`});throw e;});
 await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-solution.png`});
 if (await page.getByRole('button',{name:'Next source page'}).isEnabled()) {
  await page.getByRole('button',{name:'Next source page'}).click();
  await page.waitForTimeout(700);
  await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-solution-next.png`});
  console.log(JSON.stringify({name,solutionCanvases:await page.getByRole('dialog').locator('canvas').count(),secondPageLink:await page.getByRole('link',{name:'Open the original marking scheme'}).getAttribute('href')}));
 }
 if (await page.getByRole('button',{name:'Zoom in',exact:true}).isVisible()) await page.getByRole('button',{name:'Zoom in',exact:true}).click();
 await page.getByRole('button',{name:'Close worked solution'}).click();
 await page.getByRole('button',{name:`Set ${label} to ${selected} marks`}).click();
 await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-marks.png`});
 const aid=page.getByText(/Study aid correction, not an SEC erratum/); if(await aid.count()){await aid.evaluate(element=>element.scrollIntoView({block:'center',behavior:'instant'}));await page.waitForTimeout(400);await page.screenshot({path:`tmp/applied-mathematics-review/${target}-${name}-study-aid.png`});}
 console.log(JSON.stringify({name,errors,mark:await page.getByText(new RegExp(`Your mark: ${selected} /`)).textContent(),overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),reviewBounds:await page.locator('.mb-session-workspace').evaluate(e=>({left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,scrollLeft:e.closest('.mark-bank-theme').scrollLeft}))}));
 await page.close();
}
} finally {await browser.close()}
