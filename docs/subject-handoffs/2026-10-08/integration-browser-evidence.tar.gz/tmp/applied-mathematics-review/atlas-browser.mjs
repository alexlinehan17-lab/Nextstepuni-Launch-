import { chromium } from '/Users/alexlinehan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ headless: true, channel: 'chrome' });
const results=[];
try {
  for (const [viewport,width,height] of [['desktop',1440,1000],['phone',390,844]].filter(v=>!process.argv[3]||v[0]===process.argv[3])) {
    for (const [year,level,q,integrated] of [[2011,'ordinary','1',true],[2013,'ordinary','7',false],[2026,'ordinary','8',false],[2026,'higher','10',false]]) {
      const fileid=`LC020${level==='higher'?'A':'G'}LP000IV.pdf`;
      const map=JSON.parse(readFileSync(`public/paper-answers/${year}/${fileid}.json`,'utf8'));
      const question=map.q.find(item=>item.n===q);
      const label=`atlas-${year}-${level}-q${q}-${viewport}`;
      const page=await browser.newPage({viewport:{width,height}});
      const errors=[],failures=[],pdfs=[];
      page.on('pageerror',e=>errors.push(e.message));
      page.on('requestfailed',r=>{if(!r.failure()?.errorText.includes('ERR_ABORTED'))failures.push({url:r.url(),error:r.failure()?.errorText})});
      page.on('response',r=>{if(r.status()>=400)failures.push({url:r.url(),status:r.status()});if(r.url().includes('LC020')&&r.url().includes('alt=media'))pdfs.push(decodeURIComponent(r.url()));});
      await page.goto(`http://127.0.0.1:5488/tmp/applied-mathematics-review/atlas.html?year=${year}&level=${level}&q=${q}${integrated?'':'&single=1'}`);
      if(integrated){
        await page.getByRole('combobox',{name:'Year'}).selectOption(String(year));
        await page.getByRole('tab',{name:'Gaeilge',exact:true}).click();
        assert.equal(await page.getByRole('tab',{name:'Gaeilge',exact:true}).getAttribute('aria-selected'),'true');
        assert.equal(await page.getByRole('button',{name:'Full paper',exact:true}).count(),1);
      }
      const papers=page.locator('canvas[aria-label^="Exam paper page"]');
      await papers.nth(question.paperRegion.length-1).waitFor({timeout:45000});
      assert.equal(await papers.count(),question.paperRegion.length);
      await page.screenshot({path:`tmp/applied-mathematics-review/${label}-question.png`});
      for(let i=0;i<question.paperRegion.length;i++) await papers.nth(i).screenshot({path:`tmp/applied-mathematics-review/${label}-paper-${i+1}.png`});
      await page.getByRole('button',{name:'Show the marking scheme',exact:true}).click();
      const schemes=page.locator('canvas[aria-label^="Marking scheme page"]');
      const schemeRegion=question.schemeRegion??question.region;
      await schemes.nth(schemeRegion.length-1).waitFor({timeout:45000});
      assert.equal(await schemes.count(),schemeRegion.length);
      for(let i=0;i<schemeRegion.length;i++) await schemes.nth(i).screenshot({path:`tmp/applied-mathematics-review/${label}-scheme-${i+1}.png`});
      await page.getByRole('button',{name:'Full paper',exact:true}).click();
      const opened=JSON.parse(await page.locator('#opened').textContent());
      assert.equal(opened.fileid,fileid);assert.equal(opened.lang,'iv');assert.equal(opened.year,year);assert.equal(opened.n,q);
      assert(pdfs.some(url=>url.includes(`/paper/${fileid}`)),'Native paper not loaded');
      assert(pdfs.some(url=>url.includes(`/scheme/${map.schemeFileid}`)),'Expected scheme not loaded');
      const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
      assert.equal(overflow,false);assert.deepEqual(errors,[]);assert.deepEqual(failures,[]);
      const result={label,paperPages:question.paperRegion.map(r=>r.p),schemePages:schemeRegion.map(r=>r.p),schemeFileid:map.schemeFileid,opened,overflow,errors,failures};
      results.push(result);console.log(JSON.stringify(result));
      await page.close();
    }
  }
  writeFileSync('tmp/applied-mathematics-review/atlas-browser-results.json',JSON.stringify(results,null,2)+'\n');
} finally {await browser.close();}
