import React from 'react';
import { createRoot } from 'react-dom/client';
import SessionScreen from '../../components/MarkBank/SessionScreen';
import { REVIEWED_CARDS } from '../../components/MarkBank/cards/applied-maths/reviewed';
import '../../index.css';
const id = new URLSearchParams(location.search).get('card') || 'am-2026-ol-3-i-4kg';
createRoot(document.getElementById('root')!).render(<SessionScreen cards={[REVIEWED_CARDS.find(c => c.id === id)!]} subjectLabel="Applied Mathematics" onGrade={()=>{}} onFinish={()=>{}} onExit={()=>{}}/>);
